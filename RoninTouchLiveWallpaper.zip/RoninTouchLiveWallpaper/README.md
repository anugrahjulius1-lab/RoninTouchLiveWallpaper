# Ronin Touch Live Wallpaper

Android live wallpaper based on the generated ronin cyberpunk image.

Features:
- Touch-triggered sword/slash animation
- Bright slash line and burst
- Particle sparks
- Short system beep on touch (no audio file required)
- Designed to be lightweight and work without root

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync/download the Android Gradle Plugin.
3. Build > Build APK(s).
4. Install the APK.
5. Android Settings > Wallpaper > Live wallpapers > Ronin Touch Wallpaper.

Note:
Android decides whether a live wallpaper can appear on the lock screen separately from the launcher/home screen. On phones that support it, choose it for the lock screen when applying the wallpaper.
