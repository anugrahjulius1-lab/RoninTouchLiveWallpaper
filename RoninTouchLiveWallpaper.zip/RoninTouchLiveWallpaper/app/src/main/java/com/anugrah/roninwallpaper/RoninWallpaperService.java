package com.anugrah.roninwallpaper;

import android.graphics.*;
import android.os.Handler;
import android.service.wallpaper.WallpaperService;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.ArrayList;
import java.util.Random;

public class RoninWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new RoninEngine(); }

    class RoninEngine extends Engine {
        private final Handler handler = new Handler();
        private final Random random = new Random();
        private Bitmap bg;
        private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean visible;
        private float touchX, touchY;
        private long slashStart = 0;
        private final ArrayList<Particle> particles = new ArrayList<>();
        private ToneGenerator tone;

        private final Runnable drawRunner = new Runnable() {
            @Override public void run() {
                drawFrame();
                if (visible) handler.postDelayed(this, 16);
            }
        };

        RoninEngine() {
            bg = BitmapFactory.decodeResource(getResources(), R.drawable.ronin);
            try { tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70); } catch (Exception ignored) {}
        }

        @Override public void onVisibilityChanged(boolean v) {
            visible = v;
            if (v) { handler.removeCallbacks(drawRunner); handler.post(drawRunner); }
            else handler.removeCallbacks(drawRunner);
        }

        @Override public void onSurfaceChanged(SurfaceHolder h, int f, int w, int he) {
            super.onSurfaceChanged(h, f, w, he);
            drawFrame();
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder h) {
            visible = false;
            handler.removeCallbacks(drawRunner);
            super.onSurfaceDestroyed(h);
        }

        @Override public void onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                touchX = e.getX();
                touchY = e.getY();
                slashStart = System.currentTimeMillis();
                particles.clear();
                for (int i = 0; i < 90; i++) {
                    double a = random.nextDouble() * Math.PI * 2;
                    float speed = 2f + random.nextFloat() * 9f;
                    particles.add(new Particle(touchX, touchY, (float)Math.cos(a)*speed,
                            (float)Math.sin(a)*speed, 400 + random.nextInt(500)));
                }
                if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 100);
            }
        }

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c == null) return;
                int w = c.getWidth(), h = c.getHeight();
                paint.setAlpha(255);
                if (bg != null) {
                    Rect src = new Rect(0,0,bg.getWidth(),bg.getHeight());
                    float scale = Math.max((float)w/bg.getWidth(), (float)h/bg.getHeight());
                    int bw = Math.round(bg.getWidth()*scale), bh = Math.round(bg.getHeight()*scale);
                    Rect dst = new Rect((w-bw)/2, (h-bh)/2, (w+bw)/2, (h+bh)/2);
                    c.drawBitmap(bg, src, dst, paint);
                } else c.drawColor(Color.BLACK);

                long now = System.currentTimeMillis();
                float t = (now - slashStart) / 1000f;
                if (slashStart > 0 && t < 1.15f) {
                    float p = Math.min(1f, t / .55f);
                    float y = h * .48f + (touchY - h*.48f) * .15f;
                    float x1 = -w*.15f + p*w*1.25f;
                    float x2 = x1 - w*.22f;
                    float y1 = y - w*.16f;
                    float y2 = y + w*.16f;

                    paint.setStrokeCap(Paint.Cap.ROUND);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(20);
                    paint.setColor(Color.WHITE);
                    paint.setAlpha((int)(220*(1f-Math.max(0,t-.55f)/.6f)));
                    c.drawLine(x2,y2,x1,y1,paint);

                    paint.setStrokeWidth(7);
                    paint.setColor(Color.rgb(80,190,255));
                    paint.setAlpha(255);
                    c.drawLine(x2,y2,x1,y1,paint);

                    if (t > .22f && t < .9f) {
                        paint.setStyle(Paint.Style.FILL);
                        paint.setColor(Color.WHITE);
                        paint.setAlpha(210);
                        c.drawCircle(touchX, touchY, 18 + 55*(t-.22f), paint);
                    }

                    paint.setStyle(Paint.Style.FILL);
                    for (int i=particles.size()-1;i>=0;i--) {
                        Particle q=particles.get(i);
                        float age=(now-q.birth)/1000f;
                        q.x += q.vx; q.y += q.vy;
                        q.vy += .10f;
                        if (age > q.life/1000f) { particles.remove(i); continue; }
                        paint.setAlpha((int)(255*(1f-age/(q.life/1000f))));
                        paint.setColor(Color.rgb(130,220,255));
                        c.drawCircle(q.x,q.y,2.2f,paint);
                    }
                }
            } finally {
                if (c != null) holder.unlockCanvasAndPost(c);
            }
        }

        class Particle {
            float x,y,vx,vy; long birth,life;
            Particle(float x,float y,float vx,float vy,long life) {
                this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.birth=System.currentTimeMillis();this.life=life;
            }
        }
    }
}
